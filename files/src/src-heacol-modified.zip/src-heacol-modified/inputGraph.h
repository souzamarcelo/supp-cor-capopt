#ifndef INPUTGRAPH_INCLUDED
#define INPUTGRAPH_INCLUDED

#include "Graph.h"

void inputDimacsGraph(Graph & g, char *filename);

#endif
