#ifndef DIVERSITY_H
#define DIVERSITY_H

#include <vector>

using namespace std;

double measureDiversity(vector<vector<int> > &population, int numCols);

#endif